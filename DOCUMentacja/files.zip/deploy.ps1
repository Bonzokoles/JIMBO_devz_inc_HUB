param(
    [Parameter(Position=0)]
    [string]$Target = "help"
)

function Show-Help {
    Write-Host "🚀 Bonzo Workspace Deployment Tool" -ForegroundColor Cyan
    Write-Host "====================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Usage: .\deploy.ps1 [target]" -ForegroundColor White
    Write-Host ""
    Write-Host "Targets:" -ForegroundColor Yellow
    Write-Host "  jimbo   - Deploy JIMBO DevZ Hub to Cloudflare Workers"
    Write-Host "  blog    - Deploy MyBonzo AI Blog to Cloudflare Pages"
    Write-Host "  luc     - Deploy Luc-De-Zen to Cloudflare Pages"
    Write-Host "  zeno    - Start ZenBrowser locally (Docker)"
    Write-Host "  all     - Deploy all projects"
    Write-Host "  status  - Show deployment status"
    Write-Host ""
}

function Deploy-Jimbo {
    Write-Host "🚀 Deploying JIMBO DevZ Hub..." -ForegroundColor Yellow
    Set-Location JIMBO_devz_inc_HUB
    wrangler deploy
    Set-Location .. 
    Write-Host "✅ JIMBO Hub deployed!" -ForegroundColor Green
}

function Deploy-Blog {
    Write-Host "���� Deploying MyBonzo AI Blog..." -ForegroundColor Yellow
    Set-Location my-bonzo-ai-blog
    npm run build
    wrangler pages deploy dist
    Set-Location ..
    Write-Host "✅ MyBonzo Blog deployed!" -ForegroundColor Green
}

function Deploy-Luc {
    Write-Host "💎 Deploying Luc-De-Zen..." -ForegroundColor Yellow
    Set-Location luc-de-zen-on
    npm run build
    wrangler pages deploy dist
    Set-Location .. 
    Write-Host "✅ Luc-De-Zen deployed!" -ForegroundColor Green
}

function Deploy-Zeno {
    Write-Host "🌐 Starting ZenBrowser..." -ForegroundColor Yellow
    Set-Location zen-bro-wser.org
    docker-compose up -d
    Set-Location ..
    Write-Host "✅ ZenBrowser started on http://localhost:3000" -ForegroundColor Green
}

function Show-Status {
    Write-Host "📊 Deployment Status" -ForegroundColor Cyan
    Write-Host "====================" -ForegroundColor Cyan
    Write-Host ""
    
    Set-Location JIMBO_devz_inc_HUB
    $jimbo = git log -1 --pretty=format:'%h - %s (%cr)'
    Set-Location ..
    
    Set-Location my-bonzo-ai-blog
    $blog = git log -1 --pretty=format:'%h - %s (%cr)'
    Set-Location .. 
    
    Set-Location luc-de-zen-on
    $luc = git log -1 --pretty=format:'%h - %s (%cr)'
    Set-Location ..
    
    Set-Location zen-bro-wser.org
    $zeno = git log -1 --pretty=format:'%h - %s (%cr)'
    Set-Location ..
    
    Write-Host "JIMBO Hub:   $jimbo"
    Write-Host "Blog:       $blog"
    Write-Host "Luc-De-Zen: $luc"
    Write-Host "ZenBrowser: $zeno"
}

switch ($Target) {
    "jimbo"  { Deploy-Jimbo }
    "blog"   { Deploy-Blog }
    "luc"    { Deploy-Luc }
    "zeno"   { Deploy-Zeno }
    "all"    { 
        Deploy-Jimbo
        Deploy-Blog
        Deploy-Luc
        Deploy-Zeno
    }
    "status" { Show-Status }
    default  { Show-Help }
}