Write-Host "🔄 Bonzo Workspace - Updating All Repositories" -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ""

# Update głównego repo
Write-Host "📦 Updating workspace root..." -ForegroundColor Yellow
git pull

# Update wszystkich submodules
Write-Host "📂 Updating submodules..." -ForegroundColor Yellow
git submodule update --remote --merge

# Status
Write-Host ""
Write-Host "📊 Repository Status:" -ForegroundColor Green
Write-Host "--------------------" -ForegroundColor Green
git submodule foreach 'echo "  📁 $name"'

Write-Host ""
Write-Host "✅ All repositories updated successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "💡 To see changes: git status" -ForegroundColor Gray
Write-Host "💡 To commit submodule updates: git add . && git commit -m 'Update submodules'" -ForegroundColor Gray