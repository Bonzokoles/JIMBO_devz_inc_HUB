# 🚀 Bonzo Workspace

Multi-repository workspace for all Bonzo projects with unified development environment and deployment orchestration.

## 📂 Projects

| Project | Tech Stack | Purpose | Deployment |
|---------|-----------|---------|------------|
| **JIMBO DevZ Hub** | Cloudflare Workers, PowerShell | Central deployment hub, tunneling | Cloudflare Workers |
| **MyBonzo AI Blog** | Astro, Cloudflare Workers | AI-focused blog with API | Cloudflare Pages |
| **Luc-De-Zen** | Astro, Cloudflare D1 | Web app with database | Cloudflare Pages |
| **ZenBrowser** | Docker, Ollama, CAYD AI | AI-powered browser | Local Docker |

## 🛠️ Setup

### First Time Setup

```bash
# Clone with all submodules
git clone --recurse-submodules https://github.com/Bonzokoles/bonzo-workspace. git
cd bonzo-workspace

# Open in VS Code
code bonzo-workspace. code-workspace
```

### Install Dependencies

```bash
# JIMBO Hub
cd JIMBO_devz_inc_HUB && npm install && cd ..

# MyBonzo Blog
cd my-bonzo-ai-blog && npm install && cd .. 

# Luc-De-Zen
cd luc-de-zen-on && npm install && cd .. 

# ZenBrowser
cd zen-bro-wser.org && npm install && cd ..
```

## 🔄 Daily Workflow

### Update All Repositories

**Linux/Mac:**
```bash
./update-all.sh
```

**Windows:**
```powershell
.\update-all.ps1
```

### Work on Specific Project

```bash
# Enter project directory
cd my-bonzo-ai-blog

# Create feature branch
git checkout -b feature/new-post

# Make changes... 
# Commit and push
git add .
git commit -m "Add new blog post"
git push origin feature/new-post

# Return to workspace root
cd ..
```

### Update Submodule Reference

```bash
# After merging PR in submodule
git add my-bonzo-ai-blog
git commit -m "Update blog to v1.2"
git push
```

## 🚀 Deployment

### Deploy Individual Project

**Linux/Mac:**
```bash
./deploy.sh blog      # Deploy blog
./deploy.sh jimbo     # Deploy JIMBO Hub
./deploy.sh luc       # Deploy Luc-De-Zen
./deploy.sh zeno      # Start ZenBrowser
```

**Windows:**
```powershell
.\deploy.ps1 blog     # Deploy blog
.\deploy.ps1 jimbo    # Deploy JIMBO Hub
.\deploy.ps1 luc      # Deploy Luc-De-Zen
.\deploy.ps1 zeno     # Start ZenBrowser
```

### Deploy All Projects

```bash
./deploy.sh all       # Linux/Mac
.\deploy.ps1 all      # Windows
```

### Check Deployment Status

```bash
./deploy.sh status    # Linux/Mac
.\deploy.ps1 status   # Windows
```

## 📋 VS Code Tasks

Press `Ctrl+Shift+P` → `Tasks: Run Task`:

- 🔄 Update All Submodules
- 🚀 Deploy JIMBO Hub to Cloudflare
- 📝 Deploy MyBonzo Blog to CF Pages
- 💎 Deploy Luc-De-Zen to CF Pages
- 🌐 Start ZenBrowser (Docker)
- 🛑 Stop ZenBrowser (Docker)

## 🌿 Adding New Repository

```bash
# Add new submodule
git submodule add https://github.com/Bonzokoles/new-project.git

# Commit
git add .gitmodules new-project
git commit -m "Add new-project submodule"
git push

# Update workspace file
# Edit bonzo-workspace.code-workspace and add: 
# {
#   "name": "🆕 New Project",
#   "path": "./new-project"
# }
```

## 🔧 Troubleshooting

### Submodule Not Updated

```bash
git submodule update --init --recursive
```

### Detached HEAD in Submodule

```bash
cd my-bonzo-ai-blog
git checkout main
git pull
cd ..
```

### Reset All Submodules

```bash
git submodule foreach 'git reset --hard origin/main'
```

## 📚 Documentation

Each project has its own README: 
- [JIMBO Hub](./JIMBO_devz_inc_HUB/README.md)
- [MyBonzo Blog](./my-bonzo-ai-blog/README.md)
- [Luc-De-Zen](./luc-de-zen-on/README.md)
- [ZenBrowser](./zen-bro-wser.org/README.md)

## 🤝 Contributing

1. Create feature branch in specific submodule
2. Make changes
3. Push and create PR in submodule repo
4. After merge, update workspace reference

## 📄 License

Each project has its own license.  See individual repositories. 