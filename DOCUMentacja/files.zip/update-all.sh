#!/bin/bash

echo "🔄 Bonzo Workspace - Updating All Repositories"
echo "=============================================="
echo ""

# Update głównego repo
echo "📦 Updating workspace root..."
git pull

# Update wszystkich submodules
echo "📂 Updating submodules..."
git submodule update --remote --merge

# Status
echo ""
echo "📊 Repository Status:"
echo "--------------------"
git submodule foreach 'echo "  📁 $name:  $(git log -1 --pretty=format:%s)"'

echo ""
echo "✅ All repositories updated successfully!"
echo ""
echo "💡 To see changes:  git status"
echo "💡 To commit submodule updates: git add .  && git commit -m 'Update submodules'"