#!/bin/bash

show_help() {
  echo "🚀 Bonzo Workspace Deployment Tool"
  echo "===================================="
  echo ""
  echo "Usage: ./deploy.sh [target]"
  echo ""
  echo "Targets:"
  echo "  jimbo   - Deploy JIMBO DevZ Hub to Cloudflare Workers"
  echo "  blog    - Deploy MyBonzo AI Blog to Cloudflare Pages"
  echo "  luc     - Deploy Luc-De-Zen to Cloudflare Pages"
  echo "  zeno    - Start ZenBrowser locally (Docker)"
  echo "  all     - Deploy all projects"
  echo "  status  - Show deployment status"
  echo ""
}

deploy_jimbo() {
  echo "🚀 Deploying JIMBO DevZ Hub..."
  cd JIMBO_devz_inc_HUB
  wrangler deploy
  cd ..
  echo "✅ JIMBO Hub deployed!"
}

deploy_blog() {
  echo "📝 Deploying MyBonzo AI Blog..."
  cd my-bonzo-ai-blog
  npm run build
  wrangler pages deploy dist
  cd .. 
  echo "✅ MyBonzo Blog deployed!"
}

deploy_luc() {
  echo "💎 Deploying Luc-De-Zen..."
  cd luc-de-zen-on
  npm run build
  wrangler pages deploy dist
  cd ..
  echo "✅ Luc-De-Zen deployed!"
}

deploy_zeno() {
  echo "🌐 Starting ZenBrowser..."
  cd zen-bro-wser.org
  docker-compose up -d
  cd ..
  echo "✅ ZenBrowser started on http://localhost:3000"
}

show_status() {
  echo "📊 Deployment Status"
  echo "===================="
  echo ""
  echo "JIMBO Hub:  $(cd JIMBO_devz_inc_HUB && git log -1 --pretty=format:'%h - %s (%cr)')"
  echo "Blog:       $(cd my-bonzo-ai-blog && git log -1 --pretty=format:'%h - %s (%cr)')"
  echo "Luc-De-Zen: $(cd luc-de-zen-on && git log -1 --pretty=format:'%h - %s (%cr)')"
  echo "ZenBrowser: $(cd zen-bro-wser.org && git log -1 --pretty=format:'%h - %s (%cr)')"
}

case $1 in
  "jimbo")
    deploy_jimbo
    ;;
  "blog")
    deploy_blog
    ;;
  "luc")
    deploy_luc
    ;;
  "zeno")
    deploy_zeno
    ;;
  "all")
    deploy_jimbo
    deploy_blog
    deploy_luc
    deploy_zeno
    ;;
  "status")
    show_status
    ;;
  *)
    show_help
    ;;
esac